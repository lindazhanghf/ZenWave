import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 
import javax.sound.sampled.*; 
import java.util.Map; 
import java.util.concurrent.ConcurrentMap; 
import java.util.concurrent.ConcurrentHashMap; 
import codeanticode.syphon.*; 
import oscP5.*; 
import netP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class frontPosterMoxie extends PApplet {

/* Brain Poster by Pedro Arevalo */

//////////////////////////////////////////////////////

// Sound Library


// need to import this so we can use Mixer and Mixer.Info objects







SyphonServer server;
final static boolean is_projecting = true;

// Leap Motion Variables
int currentState = 1;
boolean wait = false;

// Project Variables
boolean rightHandCheck; // Check if hand is right or left
float handSphereRadius;
int fingers = 0;        // Number of Fingers being displayed
float strength;         // Grabbing strength
float rectY;
float[] colors = new float[5];

// Gesture triggers
Boolean changeGesture = false;
Boolean fingerChange = false;
float checkGesture = 0;
int currentFinger;
int lastFinger;

// Sketch Width and Height
int appWidth = 1000;
int appHeight = 1000;


//////////////////////////////////////////////////////

Neuron n[];
Signal s[];

boolean render = false;

// Image Variables
PImage brainCore;

// Audio File
SoundFile artBrainLoop;
SoundFile humBrainLoop;

//////////////////////////////////////////////////////

public void settings() {
  size(1000,1000, P2D);
  PJOGL.profile=1;
}

public void setup() {
//Syphon Server Setup (for projection)
  server = new SyphonServer(this, "Processing Syphon");

// Images Setup
  brainCore = loadImage("brainMask.png");

// Audio Loop
  artBrainLoop = new SoundFile (this, "artBrain.mp3");
  artBrainLoop.amp(0.6f);
  humBrainLoop = new SoundFile (this, "jazzLoop.wav");
  humBrainLoop.amp(0.4f);

  // Neuron Setup
  n = new Neuron[580];

  for(int i = 0;i<n.length;i++) { // Sections of Brain

// This is the are where the networks will be created at start!
    if (i <= 180){
      n[i] = new Neuron(i, random(500, 950), random(125, 560));
    }

    else if (i > 180 && i <= 280) {
      n[i] = new Neuron(i, random(164, 510), random(120, 420));     }

    else if (i > 280 && i <= 380) {
      n[i] = new Neuron(i, random(88, 320), random(290, 550));
    }

    else if (i > 380 && i <= 480) {
      n[i] = new Neuron(i, random(140,495), random(560,820));

    } else if (i > 480) {
      n[i] = new Neuron(i, random(302, 680), random(390, 646));
    }

  }

  for(int i = 0;i<n.length;i++) {
    n[i].makeSynapse();
  }

  rectMode(CENTER);

  for(int i = 0;i<n[0].s.length;i++) {
    n[0].makeSignal(i);
  }

  // Testing
  rectY = 200;
  fingers = 5;

  setup_Muse_Reader();
  muse_manager_setup();
}


////////////////////////////////////////////////////////

public void draw() {
  if (is_projecting)
    server.sendScreen(); // Sending screen to MadMapper via Syphon

  // Background
  if(is_human_brain()) {
    background(4, 71, 88);
  } else if (!is_human_brain()) {
    background(255);
  }

  if (Muse.in_use.state > CALIBRATION && absolute[BETA] > -0.5f && absolute[BETA] < 2) {
    // float rate = abs(1-absolute[BETA] - 1.8);
    float rate = abs(absolute[BETA] + 1 - beta_upper_limit);
    humBrainLoop.rate(rate);
  }


  pushMatrix();
  scale(1);

  for(int i = 0;i<n.length;i++) {
    n[i].drawNeuron();
  }

  popMatrix();

  resetNeurons();

  if (!is_projecting)
    image(brainCore,0,0,1000,1000);


  ////////////////////////////////////////////////////////

  draw_Muse_Reader();
}

// Helper Function
public boolean is_human_brain()
{
  if (currentState % 2 != 0)
    return true;
  // else
  return false;
}

public int find_brain_sections(float x, float y)
{
  // BRAIN SECTION 3
  if (x > 635 || x > 500 && y < 405)
    return 3;
  // BRAIN SECTION 2
  else if ((x > 250 && x <= 500 && y < 420) || (x > 10 && x <= 260 && y < 322))
    return 2;
  // BRAIN SECTION 1
  else if ((x > 10 && x < 260 && y > 270 && y < 570) || (x > 240 && x < 330 && y < 560))
    return 1;
  // BRAIN SECTION 0
  else if (x > 90 && x < 500 && y > 560)
    return 0;

  // else BRAIN SECTION 4
  return 4;
}

////////////////////////////////////////////////////////

class  Neuron {
  int id;
  float x,y,val,xx,yy;
  float radius = 60.0f;

  Synapse s[];
  Signal sig[];

  Neuron(int _id,float _x,float _y){
    val = random(255);
    id=_id;
    xx = x=_x;
    yy = y=_y;
  }

  public void makeSynapse() {

    s = new Synapse[0];
    sig = new Signal[0];

    for(int i = 0;i<n.length;i++) {
      if(i!=id && dist(x,y,n[i].x,n[i].y) <= radius && noise(i/100.0f) < 0.8f) {
        s = (Synapse[])expand(s,s.length+1);
        s[s.length-1] = new Synapse(id,i);

        sig = (Signal[])expand(sig,sig.length+1);
        sig[sig.length-1] = new Signal(s[s.length-1]);

      }
    }
  }



  public void makeSignal(int which) {
    int i = which;
    sig[i].x = xx;
    sig[i].y = yy;
    sig[i].running = true;
  }




  public void drawSynapse() {
    float beta_score = (Muse.in_use.state > CALIBRATION) ? score[BETA] : 0;
    // beta_score =  beta_score / 10 * 8 + 0.1;
    if (beta_score < 0) beta_score = 0;
    if (fitting_index > 0)
      stroke(242, 242 - (24 / 2), 13 + 24, beta_score * 60 + 30);
    else
      stroke(150, beta_score * 60 + 30);

    if (!is_human_brain())
      fill_in_synapse_AI();

    try {
      for(int i = 0;i<s.length;i+=1) {
        line(n[s[i].B].xx,n[s[i].B].yy,xx,yy);
      }
    } catch (Exception e) {
      print("BREAKS!");  //debug
    }
  }

  public void drawSignal () {

    if(sig.length > 0) {
      for(int i = 0; i < sig.length; i++) {
        if(sig[i] != null && sig[i].running) {
          try {
            pushStyle();
            // print("_"); //debug

            if(is_human_brain()) {
              strokeWeight(1); // Size of Synapse
              stroke(255, 153, 51, 70); // Color of synape
            } else {
              strokeWeight(1.5f); // Size of Synapse
              stroke(255, 0, 102, 80); // Color of synape
            }

            noFill();
            // print(sig[i].x, "|", sig[i].lx); //debug
            line(sig[i].x, sig[i].y, sig[i].lx, sig[i].ly);
            popStyle();
            sig[i].step();
            // print("✓ "); //debug
          } catch (ArrayIndexOutOfBoundsException e) {
            print("BREAKS!", sig.length, " signals ");  //debug
            println(" ", i); //debug
          }
        }
      }
    }
  }

  public void drawNeuron () {

    if (!idleChange) {
      if (Muse.in_use.state > IDLE)
        drawSignal();

      drawSynapse();
    }


    xx += (x-xx) / 8.0f; // Speed of re-organization of neurons
    yy += (y-yy) / 8.0f; // Speed of re-organization of neurons

    // if (Muse.in_use.state < DETECTION)
    if (randomly_moving && Muse.in_use.state < FITTING)
      randomMovement(); // Uncomment this to enable movement of neural networks
  }

  public void randomMovement() {
//    x+=(noise(id+BframeCount/10.0)-0.5);
//    y+=(noise(id*5+frameCount/10.0)-0.5);
    x+=(random(-0.4f,0.4f));
    y+=(random(-0.4f,0.4f));
  }

  /* Coloring function */

  // Fill in the default color of the synapse
  public void fill_in_synapse_default() {
    if(is_human_brain()){
      stroke(77, 142, 159, 45);
    } else {
      stroke(0, 51, 153, 45);
    }
  }

  public void fill_in_synapse_AI() {
    int col = (int)(abs((score[BETA] * 50) + 12)) * 2;
    stroke(0 + col, 255 - col, 0 + (col * 3), 45);
  }

}


///////////////////////////////////////////////////////

class Synapse {

  float weight = 1.5f;
  int A,B;

  Synapse(int _A, int _B){

    A=_A;
    B=_B;

    weight = random(101,1100)/300.9f; // Speed of expanding to other neurons
  }

}

//////////////////////////////////////////////////////////

class Signal {

  Synapse base;
  int cyc = 0;
  float x,y,lx,ly;
  float speed = 10.1f; // Speed of dots when re-organizing

  boolean running = false;
  boolean visible = true;

  int deadnum = 200;
  int deadcount = 0;

  Signal(Synapse _base) {
    deadnum = (int)random(2,400);
    base = _base;
    lx = x = n[base.A].x;
    ly = y = n[base.A].y;
    speed *= base.weight;
  }

  public void step() {
    running = true;

    lx = x;
    ly = y;

    x += (n[base.B].xx-x) / speed; //(speed+(dist(n[base.A].x,n[base.A].y,n[base.B].x,n[base.B].y)+1)/100.0);
    y += (n[base.B].yy-y) / speed; //(speed+(dist(n[base.A].x,n[base.A].y,n[base.B].x,n[base.B].y)+1)/100.0);

    // println(y);

    if(dist(x,y,n[base.B].x,n[base.B].y)<1.0f){

      if(deadcount < 0) {
        deadcount = deadnum;

        for(int i = 0;i<10;i++) { // To add blur in explosion

          pushStyle(); // EXPLOSION COLOR PARAMETERS
          noFill();
          noStroke();

          if (fingers >= 5) {
            fill_in_explosion();
          }

//////////////// END OF PARAMETERS

          // Position & Size of explosion
          if (Muse.in_use.state > CALIBRATION)
            ellipse(x, y, (abs((absolute[BETA] + 0.3f - beta_upper_limit) * 5)) * i, (abs((absolute[BETA] + 0.3f - beta_upper_limit) * 5)) * i);

          popStyle();
        }

        // deadnum += (int)random(-1,1);
        // println("run "+base.A+" : "+base.B);

        running = false;
        for(int i = 0; i < n[base.B].s.length;i++) {
          if(!n[base.B].sig[i].running && base.A!=n[base.B].sig[i].base.B){
            n[base.B].makeSignal(i);
            n[base.B].sig[i].base.weight += (base.weight-n[base.B].sig[i].base.weight)/((dist(x,y,n[base.A].xx,n[base.A].yy)+1.0f)/200.0f);
          }
        }

        //base.weight = random(1001,3000) / 1000.0;

        n[base.A].xx+=((n[base.B].x-n[base.A].x)/1.1f)*noise((frameCount+n[base.A].id)/11.0f);;
        n[base.A].yy+=((n[base.B].y-n[base.A].y)/1.1f)*noise((frameCount+n[base.A].id)/10.0f);

        n[base.A].xx-=((n[base.B].x-n[base.A].x)/1.1f)*noise((frameCount+n[base.B].id)/10.0f);;
        n[base.A].yy-=((n[base.B].y-n[base.A].y)/1.1f)*noise((frameCount+n[base.B].id)/11.0f);

        lx = n[base.A].xx;
        ly = n[base.A].yy;

        n[base.A].val+=(n[base.B].val-n[base.A].val)/5.0f;

      } else {

        deadcount--;
      }
    }
  }

  // Helper function
  public void fill_in_explosion()
  {
    if(is_human_brain()){
      fill(255,20);
    } else {
      fill(0, 102, 204, 20);
    }
  }
}
boolean resetDone = true;
int aiBrainX = 50;
int aiBrainY = 100;
int brainArea = 5;
boolean idleChange = false;

public void resetNeurons() {

  if(rectY > 320){
    resetDone = true;
  }

  if(resetDone == true && !is_human_brain() && rectY > 120) {
    println("Go into human BRAIN");

    currentState += 1;
    println("currentState:", currentState);
    // humBrainLoop.loop(1);
    // artBrainLoop.stop();

    for(int i = 0; i < n.length; i++) { // Sections of Brain

      if(i < 4) {
        if(brainArea == 0) {
          n[i].x = 715;
          n[i].y = 354;
        } else if (fingers == 1) {
          n[i].x = 358;
          n[i].y = 272;
        } else if (fingers == 2) {
          n[i].x = 179;
          n[i].y = 438;
        } else if (fingers == 3) {
          n[i].x = 340;
          n[i].y = 649;
        } else if (fingers == 4) {
          n[i].x = 496;
          n[i].y = 499;
        } else if (fingers == 5) {
          n[i].x = width / 2;
          n[i].y = height / 2;
        }

      } else if (i >= 5 && i <= 180) {
        n[i].x = random(500, 950);
        n[i].y = random(125, 560);
      } else if (i > 180 && i <= 280) {
        n[i].x = random(164, 510);
        n[i].y = random(120, 420);
      } else if (i > 280 && i <= 380) {
        n[i].x = random(88, 320);
        n[i].y = random(290, 550);
      } else if (i > 380 && i <= 480) {
        n[i].x = random(140,495);
        n[i].y = random(560,820);
      } else {
        n[i].x = random(302, 680);
        n[i].y = random(390, 646);
      }

    }

    fingerChange = false;

    for(int i = 0;i<n.length;i++) {
      n[i].makeSynapse();
    }

    for(int i = 0;i<n[0].s.length;i++){
      n[0].makeSignal(i);
    }

  }


//////////////////////////////////////////////////////////////
// A.I BRAIN


  if(resetDone == true && is_human_brain() && rectY < 100) { // Go into A.I BRAIN
    println("Go into A.I BRAIN");

    currentState += 1;
    println("currentState:", currentState);
    // artBrainLoop.loop(2);
    // humBrainLoop.stop();

    aiBrainX = 50;
    aiBrainY = 100;

    for(int i = 0; i < n.length; i++) { // Sections of Brain

      if(i <= 1) {
        n[i].x = width / 2;
        n[i].y = height / 2;
      } else {
        n[i].x = aiBrainX += 50;
        n[i].y = aiBrainY;

        if(aiBrainX >= 950) {
          aiBrainY += 25;
          aiBrainX = 50;
        }

      }

    }

    for(int i = 0;i<n.length;i++) {
      n[i].makeSynapse();
    }

    for(int i = 0;i<n[0].s.length;i++){
      n[0].makeSignal(i);
    }

  }


}

//////////////////////////////////////////////////////////////
// RESET BRAIN WHEN IDLE

public void idleReset() {



  if(idleChange == true) {
    int randomSpawn = PApplet.parseInt(random(0,5));
    for(int i = 0; i < n.length; i++) { // Sections of Brain

      if(i < 4) {
        if(randomSpawn == 0) {
          n[i].x = 715;
          n[i].y = 354;
        } else if (randomSpawn == 1) {
          n[i].x = 358;
          n[i].y = 272;
        } else if (randomSpawn == 2) {
          n[i].x = 179;
          n[i].y = 438;
        } else if (randomSpawn == 3) {
          n[i].x = 340;
          n[i].y = 649;
        } else if (randomSpawn == 4) {
          n[i].x = 496;
          n[i].y = 499;
        }

      } else if (i >= 5 && i <= 180) {
        n[i].x = random(500, 950);
        n[i].y = random(125, 560);
      } else if (i > 180 && i <= 280) {
        n[i].x = random(164, 510);
        n[i].y = random(120, 420);
      } else if (i > 280 && i <= 380) {
        n[i].x = random(88, 320);
        n[i].y = random(290, 550);
      } else if (i > 380 && i <= 480) {
        n[i].x = random(140,495);
        n[i].y = random(560,820);
      } else {
        n[i].x = random(302, 680);
        n[i].y = random(390, 646);
      }

    }

    idleChange = false;

    println("Reset Neurons");

    for(int i = 0;i<n.length;i++) {
      n[i].makeSynapse();
    }

    for(int i = 0;i<n[0].s.length;i++){
      n[0].makeSignal(i);
    }
  }

}
/* Muse Headbands Manager by Linda Zhang */

/*  This is used to manage more than one Muse Headbands,
    as well as for communicating with the nodeJS server
    for the web app Muse Diagram that's used for visualization
 */
//////////////////////////////////////////////////////

// Debug
final static boolean debug = false;
final static boolean debugOSC = false;

public void muse_manager_setup() {
    // Take the first muse as the default:
    Muse default_headband =
    new Muse("Muse_black");    // Connected via Muse Direct
    // new Muse("Muse_white");    // Connected via Muse Direct
    // new Muse("Person0");       // Default setting of Muse Direct (Person0/1/2)
    // new Muse("/muse");         // Default setting of Muse Monitor app
    Muse.start_using(default_headband);
}

public void oscEvent(OscMessage msg) {
    if (debugOSC) {
        print("---OSC Message---");
        println(msg);
    }

    randomly_moving = true;
    for (Muse m : Muse.get_list()) {
        getHeadbandStatus(msg, m);
    }

    getGyroscope(msg, Muse.in_use.name);
    if (Muse.in_use.state > FITTING) {
        getAbsolute(msg, Muse.in_use.name);
    }
}

public void toggle_headbands() {
    // Stop previous audio cue
    if (Muse.in_use.state < number_of_clips.length && curr_clip < number_of_clips[Muse.in_use.state])
        audio_cue[Muse.in_use.state][curr_clip].stop();

	Muse start_using = Muse.toggle();
    println("Switch to " + start_using.name);
	OscMessage myMessage = new OscMessage(start_using.name + "/toggle_on");
	myMessage.add(0);
	oscP5.send(myMessage, muse_diagram_address);
    // changeState(IDLE);
}


public void change_state(Muse m, int new_state) {
    m.state = new_state;
    OscMessage myMessage = new OscMessage(m.name + "/state");
    myMessage.add(m.state);
    oscP5.send(myMessage, muse_diagram_address);
}
/* Muse Headband Reader by Linda Zhang */

//////////////////////////////////////////////////////

// OSC data streamming


final static int recvPort = 7000;
OscP5 oscP5;
// Send data to nodeJS server (visualization)
final static NetAddress muse_diagram_address = new NetAddress("127.0.0.1", 7980);

// MACROS
final static boolean MEDITATION_MODE = true; // "true" for mediation, "false" for clam detection mode
final static int MEDITATION_TIME = 60;      // Length of the meditation time in seconds, default 60 seconds
final static int CALIBRATION_LIMIT = 100; // Minimum number of data points required for calibration
final static int NUM_CHANNEL = 4;
final static String[] BANDS = {"alpha", "beta", "gamma", "delta", "theta", "EEG"};
final static int[] COLORS = {0xffE0FFFF, 0xffFF5733, 0xffF4D03F, 0xffB0A94F, 0xff82E0AA, 0xff000000};
final static int RECT_HEIGHT = 200;
final static int RECT_WIDTH = 50;
final static int BASELINE_HEIGHT = 500;
final static int CALM_TIME = 5;   // How many consecutive seconds of calm time must be detected before entering A.I state

// Bands
final static int ALPHA = 0;
final static int BETA = 1;
final static int GAMMA = 2;
final static int DELTA = 3;
final static int THETA = 4;

// States
final static String[] STATES = {"IDLE", "FITTING", "CALIBRATION", "EXPLAINATION", "MEDITATION", "BCI", "DETECTION"};
final static int IDLE = 0;           // Headband not on
final static int FITTING = 1;        // Adjusting the headband until fitted
final static int CALIBRATION = 2;    // 20 seconds of calibration
final static int EXPLAINATION = 3;   // Guide user through 3 different interactions
final static int MEDITATION = 4;     // Meditate for 1 minute
final static int BCI = 5;            // Final state
final static int DETECTION = 6;      // Detecting 10 seconds of continuous 'calm'

// Audio Cues
final static int[] number_of_clips = {1, 2, 2, 9, 3};
SoundFile[][] audio_cue = new SoundFile[5][];
SoundFile calibration_done;
SoundFile skip_step;
int curr_clip;       // The current clip playing
int audio_time = -1; // Time when audio is done; to keep track of when to play the next clip
boolean waiting_for_nod = false;

// Data
int[] hsi_precision = new int[4];
float[] absolute = new float[5];
float[] score = new float[5];
float[] eeg = new float[4];
boolean[] good_connection = new boolean[4];
int fitting_index;
boolean has_data = false;
float[] score_bins = new float[30];
int[] score_bins_size = new int[30];

// Calibration & Detection
float beta_upper_limit = 0.3f; // Calculated by average of of Beta absolute band power during CALIBRATION state
float beta_sum;               // Sum of Beta absolute band power during CALIBRATION state
int calibration_data_points;  // The number of beta data points collected duirng CALIBRATION state
int beta_data_points;         // The number of beta data points collected duirng DETECTION / MEDITATION state
boolean start_meditation = false;
boolean nodded = false;
int gyro_position = 0;
int nod_counter;

// State Machine
// int state = IDLE;
int curr_time;
int calm_start_time = -1;
int state_start_time = -1;
int calibration_time = -1;
int milliseconds_start;

// Visualization
int last_reset_time = -1;    // Keep track of when the rest brain (position of neurons)
int rect_height = 0;
int rect_x = 0;
float diagram_bottom_y = 0;
float diagram_left = 0;
boolean randomly_moving = false;

public void setup_Muse_Reader() {
    oscP5 = new OscP5(this, recvPort);

    calibration_done = new SoundFile (this, "success.wav");
    skip_step = new SoundFile (this, "AudioCues/SKIP.wav");

    for (int i = 0; i < number_of_clips.length; i++) {
        audio_cue[i] = new SoundFile[number_of_clips[i]];
        for (int j = 0; j < number_of_clips[i]; j++) {
            audio_cue[i][j] = new SoundFile(this, "AudioCues/" + STATES[i] + String.valueOf(j) + ".wav");
        }
    }

    curr_time = current_time();
    last_reset_time = curr_time;
}

public void draw_Muse_Reader() {
    curr_time = current_time();
    fill(0);
    // println( milliseconds_start, millis() - milliseconds_start);

    if (Muse.in_use.state > FITTING && Muse.in_use.state < BCI && !waiting_for_nod && detect_nod()) { // detect_nod strict
        audio_cue[Muse.in_use.state][curr_clip].stop(); // Skip current audio
        audio_time = curr_time - 10;
        return;
    }

    // State Machine
    switch (Muse.in_use.state) {
        case 0: // IDLE
            if ((curr_time - state_start_time - 1) % 8 == 0)
                play_audio(curr_clip);

            if ((curr_time - state_start_time - 1) % 16 == 0) {
                resetBrain();
                state_start_time--;
            }
            break;
        case 1: // FITTING
            if (fitting_index >= 4 || audio_cue[Muse.in_use.state][curr_clip].isPlaying())
                break;

            if ((curr_time - state_start_time) % 10 == 0 && good_connection[1] && good_connection[2]) { // Sensors at the ears not fitted correctly
                play_audio(1);
                curr_clip = 1;
                break;
            }

            if ((curr_time - state_start_time) % 10 == 0) {
                state_start_time = curr_time - 1;
                play_audio(0);
                curr_clip = 0;
            }
            break;

        case 2: // CALIBRATION
            calibration_time =  curr_time - state_start_time;
            if (calibration_data_points >= CALIBRATION_LIMIT && curr_clip == 1)
                change_state_when_finished();
            break;

        case 3: // EXPLAINATION
            if (curr_clip == 0 && detect_nod()) {
                waiting_for_nod = false;
                play_next_clip();
            } else if (waiting_for_nod && detect_nod()) {
                println("nodded NEXT!!");
                waiting_for_nod = false;
                threshold = gyro_threshold_strict;
                skip_step.stop();
                if (curr_clip + 1 >= number_of_clips[Muse.in_use.state]) {
                    changeState(MEDITATION);
                    break;
                }
                play_next_clip();
            } else if (waiting_for_nod)
                break;

            // Do nothing if the audio is still playing
            if (audio_cue[Muse.in_use.state][curr_clip].isPlaying()) break;
            // If audio stopped:
            switch (curr_clip % 3) {
                case 0:
                    if (curr_clip == 0)
                        play_next_clip();
                    else // clip = 3, 6
                        start_wait_nod();
                    break;
                case 1:  // clip = 1, 4 or 7
                    if (audio_time < 0)
                        audio_time = curr_time;
                    else if (audio_time > 0 && curr_time - audio_time > 3)    // wait for 3 seconds and play next clip
                        play_next_clip();
                    break;
                case 2:  // clip = 2, 5, or 8
                    if (curr_clip == 8) {
                        start_wait_nod();
                        break;
                    }

                    if (audio_time < 0)
                        audio_time = curr_time;
                    else if (audio_time > 0 && curr_time - audio_time > 5)    // wait for 5 seconds and play next clip
                        play_next_clip();
                    break;
            }
            break;

        case 4: // MEDITATION

            // Do nothing if the audio is still playing
            if (audio_cue[Muse.in_use.state][curr_clip].isPlaying())
                break;

            // If audio stopped:
            if (curr_clip == 0) {
                play_next_clip();
                break;
            } else if (curr_clip == 1 && !start_meditation) {
                state_start_time = curr_time;        // reset statstate_start_time
                start_meditation = true;             // meditation starts
                milliseconds_start = millis();
                println("start_meditation");
            } else if (curr_clip == 1 && curr_time - state_start_time > MEDITATION_TIME) {
                play_next_clip();
                break;
            } else if (curr_clip == 2) {
                changeState(BCI); // last audio clip
            }
        default:
            break;
    }

    if ((curr_time - state_start_time) % 5 == 0)
        randomly_moving = false;

    // Testing
    // text("State:", 800, 15);
    // text(STATES[Muse.in_use.state], 850, 15);
    // text(curr_clip, 950, 15);

    // if (calm_start_time > 0) text(curr_time - calm_start_time, 900,40);
    // else text(curr_time - state_start_time, 900,40);
    // text(beta_upper_limit, 900,25);

    // text(calibration_data_points, 930, 40);
    // text("#data " + beta_data_points, 900, 55);

    // for (int i = 0; i < 4; i++)
    //     text((good_connection[i]?"good":"bad"), 10, 10 + i * 15);

    // // Draw bar chart
    // if (Muse.in_use.state == BCI)
    //     visualizeData(score);
    // else
    //     visualizeData(absolute);
}

public void keyReleased() {
    if (key == ENTER || key == RETURN)
       changeState(Muse.in_use.state==BCI?0:Muse.in_use.state+1);
    if (key == '\\') { // Go to previous state
        artBrainLoop.stop();
        humBrainLoop.stop();
        if (Muse.in_use.state > IDLE)
        changeState(Muse.in_use.state - 1);
    }
    else if (key == ' ') { // Space bar
        toggle_headbands();
        resetData();
    }
    else if (key == 's' && Muse.in_use.state == EXPLAINATION) { // Press 's' to skip the "tutorial"
        changeState(MEDITATION);
    }
}

public boolean detect_nod() {
    if (keyPressed && key == 'n') // manually press 'N' on keyboard to continue
        return true;
    if (nodded) {
        nodded = false;
        return true;
    }
    return false;
}

public void start_wait_nod() {
    if (audio_time < 0)
        audio_time = curr_time;
    else if (curr_time - audio_time > 3) {
        skip_step.play();
        waiting_for_nod = true;
        threshold = gyro_threshold;
        println("Play audio for 'skip by nodding'");
    }
}

public void resetData() {
    beta_upper_limit = 0.1f;
    calibration_data_points = 0;
    start_meditation = false;
    milliseconds_start = 0;
    hsi_precision = new int[4];
    good_connection = new boolean[4];
    fitting_index = 0;
}

public void resetBrain() {
    idleChange = true;
    last_reset_time = curr_time;
    idleReset();
}

public void changeState(int new_state) {
    // Old State
    if (Muse.in_use.state == CALIBRATION) {
        // Calculate average beta band from calibration
        if (calibration_data_points > 0)
            beta_upper_limit = beta_sum / calibration_data_points;
        if (Float.isNaN(beta_upper_limit) || beta_upper_limit == Float.NEGATIVE_INFINITY) // || beta_upper_limit < 0.1
            beta_upper_limit = 0.1f;
        println("Beta Upper Limit = ", beta_upper_limit);

        // For visualizing meditation result
        diagram_bottom_y = BASELINE_HEIGHT + beta_upper_limit * RECT_HEIGHT * 2;
        println ("rect y = ", diagram_bottom_y);

        // Send beta_upper_limit to BrainDiagram as a baseline of the diagram
        OscMessage baseline_msg = new OscMessage(Muse.in_use.name + "/data/baseline");
        baseline_msg.add(beta_upper_limit);
        OSC_send(baseline_msg);
    }
    else if (Muse.in_use.state == BCI) {
        resetData();
    }

    // Stop previous audio
    if (Muse.in_use.state < number_of_clips.length && curr_clip < number_of_clips[Muse.in_use.state])
        audio_cue[Muse.in_use.state][curr_clip].stop();

    // Change to new state
    print(STATES[Muse.in_use.state], "lasted for", (curr_time - state_start_time), "seconds | ");
    println("Change to new State: ", STATES[new_state]);
    change_state(Muse.in_use, new_state);
    state_start_time = curr_time;
    curr_clip = 0;
    nodded = false;

    if (new_state == IDLE) {
        resetBrain();
        artBrainLoop.stop();
        humBrainLoop.stop();
        rectY = 200;
        score_bins = new float[30];
        score_bins_size = new int[30];
    }
    else if (new_state == CALIBRATION) {
        resetBrain();
        audio_cue[Muse.in_use.state][0].play();
        humBrainLoop.loop(1);
        score_bins = new float[30];
        score_bins_size = new int[30];
    }
    else if (new_state == EXPLAINATION) {
        audio_cue[Muse.in_use.state][0].play();
        resetBrain();
    }
    else if (new_state == MEDITATION) {
        audio_cue[Muse.in_use.state][0].play();
        start_meditation = false;
    }
    else if (new_state == BCI) {
        humBrainLoop.stop();
        artBrainLoop.loop(1);
        rectY = 50;
    }
}

public void play_next_clip() {
    OscMessage myMessage = new OscMessage(Muse.in_use.name + "/audio_cue");
    myMessage.add(curr_clip + 1);
    oscP5.send(myMessage, muse_diagram_address);

    if (curr_clip + 1 < number_of_clips[Muse.in_use.state]) {
        audio_cue[Muse.in_use.state][curr_clip].stop(); // Stop the current clip
        audio_cue[Muse.in_use.state][curr_clip + 1].play();
    }
    curr_clip++;
    audio_time = -1;
}

public void play_audio(int clip_to_play) {
    if (!audio_cue[Muse.in_use.state][curr_clip].isPlaying()) {
        curr_clip = clip_to_play;
        audio_cue[Muse.in_use.state][curr_clip].play();
    }
}

/* Change to next state whenever the current audio clip has finished playing */
public void change_state_when_finished() {
    if (!audio_cue[Muse.in_use.state][curr_clip].isPlaying())
        changeState(Muse.in_use.state + 1);
}

public void collect_meditation(boolean has_beta_data) {
    if (!start_meditation)
        return;
    int timestamp = (millis() - milliseconds_start);

    OscMessage data_msg = new OscMessage(Muse.in_use.name + "/data/beta");
    data_msg.add(absolute[BETA]);
    data_msg.add(timestamp);
    data_msg.add(fitting_index);
    OSC_send(data_msg);

    data_msg = new OscMessage(Muse.in_use.name + "/data/alpha");
    data_msg.add(absolute[ALPHA]);
    data_msg.add(timestamp);
    data_msg.add(fitting_index);
    OSC_send(data_msg);
}

/* Visualization Bar Chart */
public void visualizeData(float[] data_array) {
    for (int i = 0; i < data_array.length; i++) {
        rect_x = 550 + i * 100;
        // Draw bars
        if (!is_projecting) {
            fill(COLORS[i]);
            rect_height = (int)((data_array[i] * RECT_HEIGHT));
            rect(rect_x, 700 - rect_height / 2, RECT_WIDTH, rect_height);
        }
        // Display band names and data
        fill(0);
        text(BANDS[i], rect_x - RECT_WIDTH / 2, 700 + 10);
        text(String.valueOf((float)data_array[i]), rect_x - RECT_WIDTH / 2, 700 + 22);
    }
}

public void detect_calmness() {
    if (absolute[BETA] > beta_upper_limit) {
        reset_detection();
        return;
    }

    if (absolute[ALPHA] > absolute[BETA])
    {
        beta_data_points++;

        if (calm_start_time < 0)
            calm_start_time = curr_time; // Reset start_time

        else if (curr_time - calm_start_time > CALM_TIME // 'Calm' for 10 seconds
            && beta_data_points > calibration_data_points) // Enough datapoints were collected before making the switch
        {
            changeState(BCI);
        }
    }
    else {
        reset_detection();
    }
}

public void reset_detection() {
    calm_start_time = -1;
    beta_data_points = 0;
}

/* Headband Status Information (fitting precision) */
public void getHeadbandStatus(OscMessage msg, Muse muse) {
    if (msg.checkAddrPattern(muse.name + "/elements/touching_forehead")
        && (msg.checkTypetag("i")))
    {
        debugPrint("Touching forehead? " + String.valueOf(msg.get(0).intValue()) + "\n");
        muse.headband_on = (msg.get(0).intValue() == 1);
        if (msg.get(0).intValue() == 1) {
            if (muse.state == IDLE)
                change_state(muse, FITTING);
        } else {
            if (muse.state != IDLE)
                change_state(muse, IDLE);
        }
        OSC_send(msg);
    }

    if (!muse.headband_on)
        return;

    if (msg.checkAddrPattern(muse.name + "/elements/horseshoe"))
    {
        OSC_send(msg);
        if (!muse.using)
            return;

        for (int i=0; i< NUM_CHANNEL; i++) {
            hsi_precision[i] = (int)get_OSC_value(msg, i);
            if (muse.name == "/muse") {
                good_connection[i] = hsi_precision[i] == 1;
            }

            if (Muse.in_use.state == DETECTION && hsi_precision[i] > 2)
                calm_start_time = -1; // Not fitted, restart calm detection
        }
        calculate_fitting_index();
    }

    // Strict data quality indicator for each channel, 0 = bad, 1 = good
    if (msg.checkAddrPattern(muse.name + "/elements/is_good"))
    {
        OSC_send(msg);
        if (!muse.using)
            return;

        for (int i=0; i < NUM_CHANNEL; i++) {
            good_connection[i] = get_OSC_value(msg, i) == 1;
        }
        calculate_fitting_index();
    }
}

public void calculate_fitting_index() {
    fitting_index = 0;
    for (int i=0; i < NUM_CHANNEL; i++) {
        if (good_connection[i])
            fitting_index++;
    }
    // if (Muse.in_use.state ==  FITTING && fitting_index == 4)
    //     changeState(CALIBRATION);
}

/* Absolute Band Power */
public void getAbsolute(OscMessage msg, String muse_name) {
    has_data = get_elements_data(msg, muse_name, "absolute", absolute);

    if (Muse.in_use.state == MEDITATION && msg.checkAddrPattern(muse_name + "/elements/beta_absolute"))
        collect_meditation(has_data);

    if (has_data && msg.checkAddrPattern(muse_name + "/elements/beta_absolute")) {
        if (Muse.in_use.state == DETECTION)
            detect_calmness();
        else if (calibration_data_points < CALIBRATION_LIMIT && Muse.in_use.state == CALIBRATION && calibration_time > 18 && fitting_index > 2)
        {
            beta_sum += absolute[BETA];
            calibration_data_points++;

            if (calibration_data_points == CALIBRATION_LIMIT) {
                calibration_done.play();
                play_next_clip();
            }
        }
    }
}

/* Band Power Score */
public void getScore(OscMessage msg, String muse_name) {
    get_elements_data(msg, muse_name, "session_score", score);
}


/* Gyroscope data */
final static int gyro_threshold = 30;  // Detect a nod after audio cues to continue
final static int gyro_threshold_strict = 60; // Used to skip ANY audio cues
int threshold = gyro_threshold_strict;       // Angular velocity required to trigger a "nod"
public void getGyroscope(OscMessage msg, String muse_name) {
    if (msg.checkAddrPattern(muse_name + "/gyro")) {
        float y;
        if (msg.checkTypetag("ddd"))
            y = (float) msg.get(1).doubleValue();
        else
            y = msg.get(1).floatValue();
        switch (gyro_position) {
            case 1: // Head up
                if (y < 0) {
                    gyro_position = 0;
                    nodded = true;
                    nod_counter = curr_time;
                    println("Nodded");
                    return;
                }
                break;
            case -1: // Head down
                if (y > threshold) {
                    gyro_position = 1;
                    return;
                }
                break;
            case 0:
            default :
                if (y < -1 * threshold) {
                    gyro_position = -1;
                    nod_counter = curr_time;
                    return;
                }
                break;
        }
        // Reset if nothing happens after 1 second (could be an imcomplete nod)
        if (nod_counter > 0 && curr_time - nod_counter > 1) {
            nodded = false;
            nod_counter = 0;
            gyro_position = 0;
        }
    }
}

/* Get OSC data within the "elements" category */
public boolean get_elements_data(OscMessage msg, String muse_name, String element_name, float[] data_array) {
    if (fitting_index < 2) // Bad connection
        return false;

    if (muse_name == "/muse")
        return get_elements_data_muse_monitor(msg, muse_name, element_name, data_array);

    for (int i = 0; i < BANDS.length; i++) {
        if (msg.checkAddrPattern(muse_name + "/elements/" + BANDS[i] + "_" + element_name)) {
            float sum = 0;
            for (int j = 0; j < NUM_CHANNEL; j++) {
                sum += get_OSC_value(msg, j);
            }
            sum = sum/4;

            if (!Float.isNaN(sum) && sum != data_array[i]) {
                data_array[i] = sum;
                debugPrint(" " + BANDS[i] + "=" + String.valueOf(data_array[i]));

                // calculate beta session score using beta absolute band
                if (msg.checkAddrPattern(muse_name + "/elements/beta_absolute"))
                    calculate_session_score_muse_monitor(data_array[i]);
                return true;
            }
            else {
                debugPrint(" " + BANDS[i] + "  NaN");
                return false;
            }
        }
    }
    return false;
}

public boolean get_elements_data_muse_monitor(OscMessage msg, String muse_name, String element_name, float[] data_array) {
    for (int i = 0; i < 5; i++) {
        if (msg.checkAddrPattern(muse_name + "/elements/" + BANDS[i] + "_" + element_name)) {
            data_array[i] = msg.get(0).floatValue();
            debugPrint("  " + BANDS[i] + "=" + String.valueOf(data_array[i]) + "\n");

            if (!Float.isNaN(data_array[i]))
                // calculate beta session score using beta absolute band
                if (msg.checkAddrPattern(muse_name + "/elements/beta_absolute"))
                    calculate_session_score_muse_monitor(data_array[i]);
                return true;
        }
    }
    return false;
}

/*
    Calculate band session score from absolute band power

    Algorithm derived from www.developer.choosemuse.com:
    " The band session score is computed by comparing the current value of a band power
    to its history. This current value is mapped to a score between 0 and 1 using
    a linear function that returns 0 if the current value is equal to or below the
    10th percentile of the distribution of band powers, and returns 1 if it’s
    equal to or above the 90th percentile. Linear scoring between 0 and 1 is done
    for any value between these two percentiles.

    Be advised that these scores are based on recent history and it will take a few
    seconds before having a stable distribution to score the power against. The
    estimated distribution is continuously updated as long as the headband is on
    the head. However, every time it’s updated, the newest values are weighted
    to have more importance than the historical values. This means that eventually
    old values will not be present anymore in the estimated distribution.

    The half-life of the estimated distribution at any given point is around 10 seconds. "

    Only the absolute data that's between the score_lower_bound and score_upper_bound
    will be used to calculate Band Session Score, anything else will be considered a bad data.
*/
final static float score_lower_bound = -0.5f;
final static float score_upper_bound = 1;
final static float decay_percentage = 0.9931f;
public boolean calculate_session_score_muse_monitor(float beta) {
    if (fitting_index < 2 || beta < score_lower_bound || beta >= score_upper_bound)
        return false;
    int bin_index = (int)((beta - score_lower_bound) / 0.05f);

    score_bins[bin_index] += beta;
    score_bins_size[bin_index]++;

    int total_number_points = 0;
    for (int i = 0; i < score_bins_size.length; i++) { total_number_points += score_bins_size[i]; }

    int sum_number_points = 0;
    int bin_index_10th_percentile = -1;
    int bin_index_90th_percentile = -1;
    for (int i = 0; i < score_bins_size.length; i++) {
        if (bin_index_10th_percentile < 0 && sum_number_points > total_number_points / 10)
            bin_index_10th_percentile = i - 1;
        if (bin_index_90th_percentile < 0 && sum_number_points > total_number_points / 10 * 9)
            bin_index_90th_percentile = i - 1;
        sum_number_points += score_bins_size[i];
    }
    if (bin_index_90th_percentile < 0) bin_index_90th_percentile = score_bins_size.length - 1;

    float lower_bound = bin_index_10th_percentile * 0.05f + score_lower_bound;
    float upper_bound = bin_index_90th_percentile * 0.05f + score_lower_bound;
    score[BETA] = (beta - lower_bound) / (upper_bound - lower_bound);

    for (int i = 0; i < score_bins.length; i++) {
        score_bins[i] *= decay_percentage;
    }
    // println(lower_bound, "~", upper_bound, "  result =", score[BETA]); // TODO
    return true;
}

/* EEG */
public void getEEG(OscMessage msg, String muse_name){
    if (msg.checkAddrPattern(muse_name + "/eeg")) {
            if (msg.checkTypetag("dddddd")) {
                for (int i=0; i < 4; i++) {
                    eeg[i] = (float)msg.get(i).doubleValue()/1000;
                }
            } else if (msg.checkTypetag("ffffff")) {
                for (int i=0; i < 4; i++) {
                    eeg[i] = msg.get(i).floatValue()/1000;
                }
            } else
                print("Type unknown");
    }
}

/* Blink */
public void getBlink(OscMessage msg, String muse_name) {
    if (msg.checkAddrPattern(muse_name + "/elements/blink")) {
        print("\nBlink ");
        if (msg.checkTypetag("i")) {
            print(msg.get(0).intValue());
        } else
            print("Type unknown");
    }
}

public int current_time() {
    return (hour() * 60 + minute()) * 60 + second();
}

/* get float value from "ffff" or double value from "dddd" OSC data */
public float get_OSC_value(OscMessage msg, int index) {
    if (msg.checkTypetag("ffff"))
        return msg.get(index).floatValue();
    if (msg.checkTypetag("dddd"))
        return (float)msg.get(index).doubleValue();

    debugPrint("Type unknown" + "\n");
    return Float.NaN;
}

public void OSC_send(OscMessage msg) {
  oscP5.send(msg, muse_diagram_address);
}

/* Debug helper */
public void debugPrint(String s) {
    if (debug) print(s);
}


  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "frontPosterMoxie" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
